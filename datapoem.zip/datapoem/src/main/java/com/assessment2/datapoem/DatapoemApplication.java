package com.assessment2.datapoem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatapoemApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatapoemApplication.class, args);
	}

}
